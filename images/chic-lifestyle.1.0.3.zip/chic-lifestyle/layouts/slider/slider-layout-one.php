<div class="banner-news banner-news-1 banner-news-slider text-center">
  <div class="clearfix">   
    <?php if( $title ) : ?><h4><?php echo esc_html( $title ); ?></h4><?php endif; ?>
    <section  id="owl-slider" class="owl-carousel"> 
      <?php while ( $query->have_posts() ) : $query->the_post(); ?>
          <div class="item">
          <div class="banner-news-list">
          <?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'chic_lifestyle_slider' ); ?>
              <?php
                if( ! empty( $image ) ) :
                  $image = $image[0];
                else :
                  $image = get_template_directory_uri() . '/images/no-image.jpg';
                endif;
              ?>
              <img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $title ); ?>" class="img-responsive">
              <div class="banner-news-caption">
                <?php
                  $categories = get_the_category();                    
                  $separator = ' ';
                  $output = '';
                  if ( ! empty( $categories ) ) :                     
                    foreach ( $categories as $cat ) {
                      $output .= '<h5 class="category"><a class="news-category" href="'. esc_url( get_category_link( $cat->term_id ) ) . '">' . esc_html( $cat->name ) . '</a></h5>' . $separator;
                    }
                    echo trim( $output, $separator );
                  endif; ?>
                <h4 class="news-title"><a href="<?php echo esc_url( get_the_permalink( $post->ID ) ); ?>"><?php the_title(); ?></a></h4>
                <div class="info"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo get_the_date(); ?></div><?php the_excerpt();?>
                <a href="<?php echo esc_url( get_the_permalink( $post->ID ) ); ?>" class="readmore">Read More</a>
              </div> 
          </div>
          </div>
      <?php endwhile; wp_reset_postdata(); ?>
    </section> 
  </div>
</div>