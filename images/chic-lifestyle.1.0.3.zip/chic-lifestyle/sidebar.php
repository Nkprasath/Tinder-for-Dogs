<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package chic-lifestyle
 */
?>

<div id="secondary" class="widget-area" role="complementary">
	<?php dynamic_sidebar( 'right-sidebar' ); ?>
</div><!-- #secondary -->