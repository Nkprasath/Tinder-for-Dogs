<?php
/**
 * Header Layout Settings
 *
 * @package chic-lifestyle
 */

add_action( 'customize_register', 'chic_lifestyle_customize_register_header_layouts' );

function chic_lifestyle_customize_register_header_layouts( $wp_customize ) {

    Kirki::add_section( 'chic_lifestyle_header_layout_section', array(
        'title'          => esc_attr__( 'Header Options', 'chic-lifestyle' ),
        'description'    => esc_attr__( 'Header Options', 'chic-lifestyle' ),
        'panel'          => '',
        'priority'       => 9,
        'capability'     => 'edit_theme_options',
    ) );

    Kirki::add_field( 'chic_lifestyle_header_sticky_menu_option', array(
        'type'        => 'checkbox',
        'settings'    => 'chic_lifestyle_header_sticky_menu_option',
        'label'       => esc_attr__( 'Make menu sticky?', 'chic-lifestyle' ),
        'description' => esc_attr__( 'Check the box to make menu sticky.', 'chic-lifestyle' ),
        'section'     => 'chic_lifestyle_header_layout_section',
        'default'     => false,
    ) );
    
    Kirki::add_field( 'chic_lifestyle_header_layouts', array(
        'type'        => 'radio-image',
        'settings'    => 'chic_lifestyle_header_layouts',
        'label'       => esc_html__( 'Layouts', 'chic-lifestyle' ),        
        'section'     => 'chic_lifestyle_header_layout_section',
        'default'     => 'one',
        'priority'    => 10,
        'choices'     => array(
            'one'   => get_template_directory_uri() . '/images/header-layouts/one.jpg',
        ),
    ) );
}