<?php /**  
* The template used for displaying page content in page.php  
*  
* @package chic-lifestyle  */

?>

<div class="page-title">
	<h1><?php the_title(); ?></h1>
</div>

<div class="single-post">
	<div class="post-content">
		<figure class="feature-image">
			<?php if ( has_post_thumbnail() && ! post_password_required() ) : ?>				
				<?php the_post_thumbnail('full'); ?>
			<?php else : ?>
				<img src="<?php echo esc_url( get_template_directory_uri() . '/images/no-image.jpg' ); ?>">		
			<?php endif; ?>
		</figure>
		<article>
			<?php the_content(); ?>
			<?php wp_link_pages( array( 'before' => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'chic-lifestyle' ) . '</span>', 'after' => '</div>', 'link_before' => '<span>', 'link_after' => '</span>' ) ); ?>
		</article> <!-- /.end of article -->
	</div>


</div>


<div class="entry-meta">
	<?php edit_post_link( __( 'Edit', 'chic-lifestyle' ), '<span class="edit-link">', '</span>' ); ?>
</div><!-- .entry-meta -->