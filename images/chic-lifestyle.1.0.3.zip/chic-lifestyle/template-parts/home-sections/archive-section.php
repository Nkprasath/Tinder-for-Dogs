<?php dynamic_sidebar( 'newsletter-sidebar' ); ?>

<?php if( get_theme_mod( 'archive_display', $default = true ) ) : ?>
    <?php       
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        $default_posts_per_page = get_option( 'posts_per_page' );
        $archive_cat = get_theme_mod( 'archive_category' );
        $args = array(
            'post_type' => 'post',
            'cat'       => esc_attr( $archive_cat ),
            'posts_per_page'    => esc_attr( $default_posts_per_page ),
            'paged'     => esc_attr( $paged )
        );
        $query = new WP_Query( $args );

        $max_pages = $query->max_num_pages;
    ?>

    <?php
        $layout = get_theme_mod( 'chic_lifestyle_post_layout', 'sidebar-right' );
        $view = get_theme_mod( 'chic_lifestyle_post_view', 'list-view' );

        $content_column_class = 'col-sm-9';
        $sidebar_left_class = 'col-sm-3';
        $sidebar_right_class = 'col-sm-3';

        if( $layout == 'full-width' ) {
            $content_column_class = 'col-sm-12';
        }
        
        if ( $query->have_posts() ) { ?>
            <div class="home-archive inside-page post-list">
                <div class="container">        
                    <div class="row">
                    	<?php if( $layout == 'sidebar-left' ) { ?>
                    		<div class="<?php echo esc_attr( $sidebar_left_class ); ?>"><?php dynamic_sidebar( 'left-sidebar' ); ?></div>
                    	<?php } ?>
                        <div class="<?php echo esc_attr( $content_column_class ); ?>">
                            <?php $archive_title = get_theme_mod( 'archive_title' ); ?>
                              <?php if( ! empty( $archive_title ) ) { ?><h2 class="news-heading"><?php echo esc_html( $archive_title ); ?></h2><?php } ?>
                        	<div class="<?php echo esc_attr( $view ); ?> row">                                         
	                          
	                              <?php /* Start the Loop */ ?>
	                              <?php while ( $query->have_posts() ) : $query->the_post(); ?>
	                                  <?php

	                                      /*
	                                       * Include the Post-Format-specific template for the content.
	                                       * If you want to override this in a child theme, then include a file
	                                       * called content-___.php (where ___ is the Post Format name) and that will be used instead.
	                                       */
	                                      get_template_part( 'template-parts/content' );
	                                  ?>
	                              <?php endwhile; ?>                                       
	                          
	                            <ul class="pagination">
	                              <li id="previous-posts">
	                                <?php previous_posts_link( '<< Previous Posts', $max_pages ); ?>
	                              </li>
	                              <li id="next-posts">
	                                <?php next_posts_link( 'Next Posts >>', $max_pages ); ?>
	                              </li>
	                            </ul>
	                          <?php wp_reset_postdata(); ?>
	                        </div>
                        </div>
                        <?php if( $layout == 'sidebar-right' ) { ?>
                    		<div class="<?php echo esc_attr( $sidebar_right_class ); ?>"><?php get_sidebar(); ?></div>
                    	<?php } ?>
                    </div>
                </div>
            </div>
            
            
        <?php } ?>
    
<?php endif; ?>